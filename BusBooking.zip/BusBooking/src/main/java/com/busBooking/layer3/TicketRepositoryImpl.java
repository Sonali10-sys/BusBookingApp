package com.busBooking.layer3;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.busBooking.layer2.Ticket;

@Repository
public class TicketRepositoryImpl implements TicketRepository {

	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public Ticket getBookedTicketById(int ticketId) {
		// TODO Auto-generated method stub
		return entityManager.find(Ticket.class,ticketId);
	}
	
	
	@Override
	@Transactional
	public Ticket updateTicket(Ticket ticket) {
		// TODO Auto-generated method stub
		return entityManager.merge(ticket);
	}

}
