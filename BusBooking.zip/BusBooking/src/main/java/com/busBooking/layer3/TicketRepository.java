package com.busBooking.layer3;

import com.busBooking.layer2.Ticket;

public interface TicketRepository {
	public Ticket getBookedTicketById(int ticketId);
	
	public Ticket updateTicket(Ticket ticket);
}
