package com.busBooking.layer4;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.busBooking.layer2.Ticket;
import com.busBooking.layer3.TicketRepository;

@Service
public class TicketServiceImpl implements TicketService{
	
	@Autowired
	TicketRepository ticketRepo;
	
	@Override
	public Ticket getTicketByIdService(int ticketId) {
		// TODO Auto-generated method stub
		return ticketRepo.getBookedTicketById(ticketId);
	}

	@Override
	public Ticket updateTicketService(Ticket ticket) {
		// TODO Auto-generated method stub
		return ticketRepo.updateTicket(ticket);
	}

}
