package com.busBooking.layer4;

import com.busBooking.layer2.Ticket;

public interface TicketService {
	public Ticket getTicketByIdService(int ticketId);
	
	public Ticket updateTicketService(Ticket ticket);
}
