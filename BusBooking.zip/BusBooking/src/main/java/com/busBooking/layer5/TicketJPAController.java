package com.busBooking.layer5;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.busBooking.layer2.Ticket;
import com.busBooking.layer4.TicketService;

@CrossOrigin
@RestController
@RequestMapping("/busJPA")
public class TicketJPAController {
	
	@Autowired
	TicketService ticketService;
	
	@GetMapping("/getBookedTicket/{ticketId}")//http://localhost:8080/busJPA/getBookedTicket/{ticketId}
	public Ticket getTicketById(@PathVariable("ticketId") int ticketId) {
		return ticketService.getTicketByIdService(ticketId);
	}
	
	@PutMapping("/updateTicket")//http://localhost:8080/busJPA/updateTicket
	public Ticket updateTicket(@RequestBody Ticket updateTicket) {
		return ticketService.updateTicketService(updateTicket);
	}
}
