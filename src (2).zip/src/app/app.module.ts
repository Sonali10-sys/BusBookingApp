import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CancelTicketComponent } from './cancel-ticket/cancel-ticket.component';
import { TempComponent } from './temp/temp.component';
import {RouterModule,Routes} from '@angular/router';
import { HttpClientModule } from '@angular/common/http';

const routes:Routes=[
  {path:'',component:AppComponent},
  {path:'cancelTicket',component: CancelTicketComponent},
  {path:'**',component:AppComponent},
]
@NgModule({
  declarations: [
    AppComponent,
    CancelTicketComponent,
    TempComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    AppRoutingModule,
    RouterModule.forRoot(routes),
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
