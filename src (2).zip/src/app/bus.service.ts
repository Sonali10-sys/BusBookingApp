
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Ticket } from './cancel-ticket/Ticket';

@Injectable({
  providedIn: 'root'
})
export class BusService {

  constructor(private myHttp: HttpClient) { }

  getticketById(ticketId:number):Observable<Ticket>{
    return this.myHttp.get<Ticket>("http://localhost:8080/busJPA/getBookedTicket/"+ticketId);
  }

  cancelTicket(updatedTicket:Ticket){
   return this.myHttp.put<Ticket>("http://localhost:8080/busJPA/updateTicket",updatedTicket);
  }
}
